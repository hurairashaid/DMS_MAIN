const express = require("express");
const cors = require("cors");
const connectDB = require("./database/connect");

const PORT = process.env.PORT || 2000;
const app = express();
// app.use(bodyParser.json()); // Support JSON-encoded bodies.
// Middleware
app.use(cors()); // Allow all origins
app.use(express.json()); // Parse JSON bodies
app.use(express.urlencoded({ extended: false })); // Parse URL-encoded bodies

// Routes
const userRoutes = require("./routes/user");
const evacuationRoutes = require("./routes/evacuation");
const chatRoutes = require("./routes/chat");
app.use("/dmsapi/user", userRoutes);
app.use("/dmsapi/evacuation", evacuationRoutes);
app.use("/dmsapi/chat", chatRoutes);

app.get('/', (req, res) => {
  res.status(200).json({ message: "This is a test endpoint" });
});

// Socket.io setup
const { createServer } = require("http");
const { Server } = require("socket.io");

const httpServer = createServer();
const io = new Server(httpServer, {
  cors: {
    origin: "*",
  },
});

io.on("connection", (socket) => {
  console.log("what is socket ");
  console.log("socket is active to be connected");

  socket.on("setup", (userData) => {
    socket.join(userData);
    console.log(userData);
    socket.emit("connected");
  });

  socket.on("join chat", (group) => {
    socket.join(group);
    console.log("user Joined Room " + group);
  });

  // socket.on("new message", (newMessageRecieved) => {
  //   socket.in(group).emit("message recieved", newMessageRecieved);
  // });

  socket.on("new message", (newMessageRecieved) => {
    const messageLength = newMessageRecieved.data.addMessage.messages.length;

    console.log(
      "this is the message",
      newMessageRecieved.data.addMessage.messages[messageLength - 1]
    );
    console.log("this is the group ID", newMessageRecieved.data.addMessage._id);
    socket.broadcast
      .to(newMessageRecieved.data.addMessage._id)
      .emit(
        "message recieved",
        newMessageRecieved.data.addMessage.messages[messageLength - 1]
      );
  });
});

httpServer.listen(3000, () => {
  console.log("server for socket is running");
});

// Start server
const startServer = async () => {
  try {
    await connectDB(); // Connect to MongoDB or any other database
    app.listen(PORT, () => {
      console.log(`Server is running at http://localhost:${PORT}`);
    });
  } catch (error) {
    console.error("Error starting server:", error.message);
  }
};

startServer();
